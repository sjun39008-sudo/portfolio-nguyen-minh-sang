PORTFOLIO NGUYỄN MINH SANG – VERCEL
Mở index.html để xem trước.
Để triển khai trên Vercel Drop, tải thư mục đã giải nén chứa index.html.
Bài tập 1 sử dụng ảnh thực hành do người dùng cung cấp, đã cắt phần đồng hồ ở thanh tác vụ.
Bài tập 2–6 là khung chờ nội dung thực tế, không sao chép từ Portfolio gốc.
